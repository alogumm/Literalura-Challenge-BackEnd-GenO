
package com.alura.literalura.service;

import com.alura.literalura.model.Book;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {
    
    public Book searchBook(String title) {
        // Logic to search and return a book from the API and save it to the database
        return new Book();
    }

    public List<Book> getAllBooks() {
        // Logic to return all books from the database
        return List.of(new Book());
    }

    public List<String> getAllAuthors() {
        // Logic to return all authors from the database
        return List.of("Author");
    }
}
